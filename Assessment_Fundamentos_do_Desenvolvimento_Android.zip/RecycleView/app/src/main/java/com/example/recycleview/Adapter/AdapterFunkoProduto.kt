package com.example.recycleview.Adapter


import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.recycleview.R
import com.example.recycleview.model.FunkoProduto


class AdapterProduto(private val context: Context, private val produtos: MutableList<FunkoProduto>): RecyclerView.Adapter<AdapterProduto.ProdutoViewHolder>() {

    //Responsável por criar as visualizações em tela
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProdutoViewHolder {
        val itemLista = LayoutInflater.from(context).inflate(R.layout.funkopop_item, parent, false)
        val holder = ProdutoViewHolder(itemLista)
        return holder
    }

    //Responsável por exibir as visualizações na tela
    override fun onBindViewHolder(holder: ProdutoViewHolder, position: Int) {
        holder.foto.setImageResource(produtos[position].fotoFunko)
        holder.nome.text = produtos[position].nomeFunko
        holder.descricao.text = produtos[position].descricaoFunko
        holder.grau.text = produtos[position].grauFunko

    }

    override fun getItemCount(): Int = produtos.size


    inner class ProdutoViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val foto = itemView.findViewById<ImageView>(R.id.fotoFunko)
        val nome = itemView.findViewById<TextView>(R.id.nomeFunko)
        val descricao = itemView.findViewById<TextView>(R.id.descricaoFunko)
        val grau = itemView.findViewById<TextView>(R.id.grauFunko)
    }
}
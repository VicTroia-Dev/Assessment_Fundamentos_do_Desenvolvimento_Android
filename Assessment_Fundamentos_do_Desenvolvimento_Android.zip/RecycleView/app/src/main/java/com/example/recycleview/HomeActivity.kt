package com.example.recycleview

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class HomeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        val button_vitrine = findViewById<Button>(R.id.btn_vitrine_digital)
        val button_colecao = findViewById<Button>(R.id.btn_colecao)

        button_vitrine.setOnClickListener{
            val singupIntent = Intent(this, VitrineActivity::class.java)
            startActivity(singupIntent)
        }

        button_colecao.setOnClickListener{
            val singupIntent = Intent(this, ColecaoActivity::class.java)
            startActivity((singupIntent))
        }

    }
}
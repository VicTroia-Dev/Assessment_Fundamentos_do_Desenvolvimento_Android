package com.example.recycleview

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.recycleview.Adapter.AdapterProduto
import com.example.recycleview.model.FunkoProduto

class VitrineActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_vitrine)

        //Intent Implicita
        val sendIntent: Intent = Intent().apply {
            action = Intent.ACTION_SEND
            putExtra(Intent.EXTRA_TEXT, "Venha conhecer o aplicativo do Funko Pop e ter acesso a uma vitrine incrível de novidades! Além de um controle de toda a sua coleção.")
            type = "text/plain"
        }
        startActivity(sendIntent)

        val recycledView_produtosFunkos = findViewById<RecyclerView>(R.id.recyclerView_funkoProdutos)
        recycledView_produtosFunkos.layoutManager = LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false)
        recycledView_produtosFunkos.setHasFixedSize(true)

        // Configuração do Adapter

        val listaProdutos: MutableList<FunkoProduto> = mutableListOf()
        val adapterProduto = AdapterProduto(this, listaProdutos)
        recycledView_produtosFunkos.adapter = adapterProduto

        val funko1 = FunkoProduto(
            R.drawable.abuela_madrigal,
            "Abuela Alma Madrigal",
            "Personagem do filme Encanto, da Disney",
            "Peça Rara"
        )
        listaProdutos.add(funko1)

        val funko2 = FunkoProduto(
            R.drawable.antonio_madrigal,
            "Antônio Madrigal",
            "Personagem do filme Encanto, da Disney",
            "Peça Comum"
        )
        listaProdutos.add(funko2)

        val funko3 = FunkoProduto(
            R.drawable.isabela_madrigal,
            "Isabella Madrigal",
            "Personagem do filme Encanto, da Disney",
            "Peça Comum"
        )
        listaProdutos.add(funko3)

        val funko4 = FunkoProduto(
            R.drawable.julieta_madrigal,
            "Julieta Madrigal",
            "Personagem do filme Encanto, da Disney",
            "Peça Comum"
        )
        listaProdutos.add(funko4)

        val funko5 = FunkoProduto(
            R.drawable.hawkeye_hawkeye,
            "Hawkeye",
            "Personagem da Marvel, peça da série Hawkeye",
            "Peça Comum"
        )
        listaProdutos.add(funko5)

        val funko6 = FunkoProduto(
            R.drawable.hawkeye_maya_lopes,
            "Maya Lopes",
            "Personagem da Marvel, peça da série Hawkeye",
            "Peça Comum"
        )
        listaProdutos.add(funko6)

        val funko7 = FunkoProduto(
            R.drawable.loki_kid,
            "Kid Loki",
            "Personagem da Marvel, peça da série Loki",
            "Peça Rara"
        )
        listaProdutos.add(funko7)

        val funko8 = FunkoProduto(
            R.drawable.loki_aligator,
            "Kid Loki",
            "Personagem da Marvel, peça da série Loki",
            "Peça Rara"
        )
        listaProdutos.add(funko8)

        val funko9 = FunkoProduto(
            R.drawable.loki_sylvie,
            "Kid Loki",
            "Personagem da Marvel, peça da série Loki",
            "Peça Comum"
        )
        listaProdutos.add(funko9)

        val funko10 = FunkoProduto(
            R.drawable.matrix_morpheus,
            "Morpheus",
            "Personagem da saga de filmes Matrix, da Warner Bros.",
            "Peça Comum"
        )
        listaProdutos.add(funko10)

        val funko11 = FunkoProduto(
            R.drawable.matrix_cyber_neo,
            "Neo in Matrix",
            "Personagem da saga de filmes Matrix, da Warner Bros.",
            "Peça Rara"
        )
        listaProdutos.add(funko11)

        val funko12 = FunkoProduto(
            R.drawable.the_witch_yennefer,
            "Yennefer",
            "Personagem da série The Witcher, da Netflix",
            "Peça Comum"
        )
        listaProdutos.add(funko12)

        val funko13 = FunkoProduto(
            R.drawable.the_witch_geralt,
            "Geralt",
            "Personagem da série The Witcher, da Netflix",
            "Peça Comum"
        )
        listaProdutos.add(funko13)

        val funko14 = FunkoProduto(
            R.drawable.the_witch_crazy_geralt,
            "Geralt Witcher",
            "Personagem da série The Witcher, da Netflix",
            "Peça Rara"
        )
        listaProdutos.add(funko14)

    }
}
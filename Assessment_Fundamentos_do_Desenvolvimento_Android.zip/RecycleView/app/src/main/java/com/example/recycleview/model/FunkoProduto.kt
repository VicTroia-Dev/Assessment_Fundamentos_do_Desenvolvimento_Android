package com.example.recycleview.model

import android.widget.Button

data class FunkoProduto(

    val fotoFunko: Int,
    val nomeFunko: String,
    val descricaoFunko: String,
    val grauFunko: String
)
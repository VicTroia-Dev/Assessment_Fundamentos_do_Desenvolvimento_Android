package com.example.recycleview

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val button_iniciar = findViewById<Button>(R.id.btn_iniciar)

        button_iniciar.setOnClickListener{
            val singupIntent = Intent(this, DireitosActivity::class.java)
            startActivity(singupIntent)
        }
    }
}
package com.example.recycleview

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class TotalViewsModel : ViewModel() {
    val total = MutableLiveData<Int>()

    init {

        total.postValue(0)

    }

    fun increaseTotal() {

        total.postValue((total.value ?: 0) + 1)

    }


    fun getTotal(): LiveData<Int> {

        return total

    }
}